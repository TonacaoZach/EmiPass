package com.example.emipass

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import android.widget.Button
import android.widget.Toast

class ActivityLogin : AppCompatActivity() {

    private lateinit var btnLogin: Button
    private lateinit var dbHelper: DBHelper
    private lateinit var etPhone: EditText
    private lateinit var etPwd: EditText
    private lateinit var Signuphere: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        dbHelper = DBHelper(this)
        etPhone = findViewById(R.id.phonenumber_login)
        etPwd = findViewById(R.id.password_login)
        btnLogin = findViewById(R.id.btn_login)
        Signuphere = findViewById(R.id.signuphere)

        Signuphere.setOnClickListener {
            val signup = Intent(this, ActivityRegister::class.java)
            startActivity(signup)
            finish()
        }

        btnLogin.setOnClickListener {
            val isLoggedID = dbHelper.checkPhone(etPhone.text.toString(), etPwd.text.toString())
            if (isLoggedID) {
                val main = Intent(this@ActivityLogin, WelcomeSplash::class.java)
                startActivity(main)
                finish()
            } else {
                Toast.makeText(this@ActivityLogin, "Login Failed", Toast.LENGTH_LONG).show()
            }
        }
    }
}