package com.example.emipass;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DBName = "register.db";

    public DBHelper(@Nullable Context context){
        super(context, DBName, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (phonenumber INTEGER PRIMARY KEY, password TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists users");
    }

    public boolean insertData(String phonenumber, String password) {
        SQLiteDatabase myDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("phonenumber", phonenumber);
        contentValues.put("password", password);
        long result = myDB.insert("users",null,contentValues);
        return result != -1;
    }



    public String getPhoneNumber() {
        SQLiteDatabase myDB = this.getReadableDatabase();
        Cursor cursor = myDB.rawQuery("SELECT phonenumber FROM users LIMIT 1", null);
        if (cursor != null && cursor.moveToFirst()) {
            String phoneNumber = cursor.getString(0);
            cursor.close();
            return phoneNumber;
        }
        return null;
    }

    public boolean checkPhone(String phone) {
        SQLiteDatabase myDB = this.getWritableDatabase();
        Cursor cursor = myDB.rawQuery("select * from users where phonenumber = ?", new String[]{phone});
        if (cursor.getCount() > 0)
            return true;
        else return false;
    }

    public boolean checkPhone(String phone, String pwd){
        SQLiteDatabase myDB = this.getWritableDatabase();
        Cursor cursor = myDB.rawQuery("select * from users where phonenumber = ? and password = ?", new String[]{phone, pwd} );
        if (cursor.getCount() > 0)
            return true;
        else return false;
    }
}
