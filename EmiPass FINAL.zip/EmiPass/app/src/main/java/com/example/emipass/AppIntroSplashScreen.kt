package com.example.emipass

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import androidx.appcompat.app.AppCompatActivity

class AppIntroSplashScreen : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_intro_splash_screen)

        Handler().postDelayed({
            val start = Intent(this@AppIntroSplashScreen, ActivityLogin::class.java)
            startActivity(start)
            finish()
        }, 3000)
    }
}