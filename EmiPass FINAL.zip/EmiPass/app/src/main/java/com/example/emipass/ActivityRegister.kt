package com.example.emipass

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class ActivityRegister : AppCompatActivity() {

    private lateinit var etPhone: EditText
    private lateinit var etPwd: EditText
    private lateinit var etRepwd: EditText
    private lateinit var btnRegister: Button
    private lateinit var dbHelper: DBHelper
    private lateinit var Loginhere: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        etPhone = findViewById(R.id.phonenumber_signup)
        etPwd = findViewById(R.id.password_signup)
        etRepwd = findViewById(R.id.repassword_signup)
        btnRegister = findViewById(R.id.btn_signup)
        Loginhere = findViewById(R.id.loginhere)
        dbHelper = DBHelper(this)

        Loginhere.setOnClickListener {
            val login = Intent(this@ActivityRegister, ActivityLogin::class.java)
            startActivity(login)
            finish()
        }

        btnRegister.setOnClickListener {
            val phone = etPhone.text.toString()
            val pwd = etPwd.text.toString()
            val rePwd = etRepwd.text.toString()

            when {
                phone.isEmpty() || pwd.isEmpty() || rePwd.isEmpty() -> {
                    Toast.makeText(this@ActivityRegister, "Please fill all the fields", Toast.LENGTH_LONG).show()
                }
                pwd != rePwd -> {
                    Toast.makeText(this@ActivityRegister, "Passwords do not match!", Toast.LENGTH_LONG).show()
                }
                dbHelper.checkPhone(phone) -> {
                    Toast.makeText(this@ActivityRegister, "Phone already in use.", Toast.LENGTH_LONG).show()
                }
                else -> {
                    val registeredSuccess = dbHelper.insertData(phone, pwd)
                    if (registeredSuccess) {
                        Toast.makeText(this@ActivityRegister, "Registered Successfully!", Toast.LENGTH_LONG).show()
                        val success = Intent(this@ActivityRegister, ActivityLogin::class.java)
                        startActivity(success)
                        finish()
                    } else {
                        Toast.makeText(this@ActivityRegister, "Registration Failed.", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }
}