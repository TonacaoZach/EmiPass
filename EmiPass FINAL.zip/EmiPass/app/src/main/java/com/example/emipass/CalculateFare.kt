package com.example.emipass

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.gms.common.api.Status
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.widget.Autocomplete
import com.google.android.libraries.places.widget.AutocompleteActivity
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode
import java.util.*

class CalculateFare : Fragment() {

    private lateinit var etSource: EditText
    private lateinit var etDestination: EditText
    private lateinit var textView: TextView
    private lateinit var taxiFareTextView: TextView
    private lateinit var busFareTextView: TextView
    private lateinit var carFuelCostTextView: TextView
    private lateinit var directionsbtn: Button

    private var sType: String = ""
    private var lat1 = 0.0
    private var long1 = 0.0
    private var lat2 = 0.0
    private var long2 = 0.0
    private var flag = 0

    private lateinit var autocompleteLauncher: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Places.initialize(requireContext(), "AIzaSyB3c0lOe49vcABflZT9sFJajFWdgT0vdAg")

        autocompleteLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == AppCompatActivity.RESULT_OK) {
                val place = Autocomplete.getPlaceFromIntent(result.data!!)
                handlePlaceSelected(place)
            } else if (result.resultCode == AutocompleteActivity.RESULT_ERROR) {
                val status = Autocomplete.getStatusFromIntent(result.data!!)
                Toast.makeText(requireContext(), status.statusMessage, Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_calculate_fare, container, false)

        directionsbtn = view.findViewById(R.id.directions)
        etSource = view.findViewById(R.id.et_source)
        etDestination = view.findViewById(R.id.et_destination)
        textView = view.findViewById(R.id.distance)
        taxiFareTextView = view.findViewById(R.id.taxi_fare)
        busFareTextView = view.findViewById(R.id.bus_fare)
        carFuelCostTextView = view.findViewById(R.id.car_fuel_cost)

        directionsbtn.setOnClickListener {
            val source = etSource.text.toString()
            val destination = etDestination.text.toString()
            if (source.isEmpty() || destination.isEmpty()) {
                Toast.makeText(context, "Enter All Fields", Toast.LENGTH_SHORT).show()
            } else {
                val uri = Uri.parse("https://www.google.com/maps/dir/$source/$destination")
                val direct = Intent(Intent.ACTION_VIEW, uri).apply {
                    setPackage("com.google.android.apps.maps")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                startActivity(direct)
            }
        }

        etSource.isFocusable = false
        etSource.setOnClickListener {
            sType = "source"
            startAutocompleteActivity()
        }

        etDestination.isFocusable = false
        etDestination.setOnClickListener {
            sType = "destination"
            startAutocompleteActivity()
        }

        textView.text = "0.0 Kilometers"
        taxiFareTextView.text = "Taxi Fare: AED 0.00"
        busFareTextView.text = "Bus Fare: AED 0.00"
        carFuelCostTextView.text = "Car Fuel Cost: AED 0.00"

        return view
    }

    private fun startAutocompleteActivity() {
        val fields = listOf(Place.Field.ADDRESS, Place.Field.LAT_LNG)
        val intent = Autocomplete.IntentBuilder(
            AutocompleteActivityMode.OVERLAY, fields
        ).build(requireContext())
        autocompleteLauncher.launch(intent)
    }

    private fun handlePlaceSelected(place: Place) {
        if (sType == "source") {
            flag++
            etSource.setText(place.address)
            var sSource = place.latLng.toString()
            sSource = sSource.replace("lat/lng:", "").replace("(", "").replace(")", "")
            val split = sSource.split(",").toTypedArray()
            lat1 = split[0].toDouble()
            long1 = split[1].toDouble()
        } else {
            flag++
            etDestination.setText(place.address)
            var sDestination = place.latLng.toString()
            sDestination = sDestination.replace("lat/lng:", "").replace("(", "").replace(")", "")
            val split = sDestination.split(",").toTypedArray()
            lat2 = split[0].toDouble()
            long2 = split[1].toDouble()
        }
        if (flag >= 2) {
            calculateDistanceAndFares()
        }
    }

    private fun calculateDistanceAndFares() {
        val R = 6371 // Radius of the Earth in kilometers
        val latDistance = Math.toRadians(lat2 - lat1)
        val lonDistance = Math.toRadians(long2 - long1)
        val a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
        val distance = R * c // convert to kilometers
        textView.text = String.format(Locale.US, "%.2f Kilometers", distance)

        val taxiFare = distance * 1.82
        if (taxiFare < 12) {
            taxiFareTextView.text = String.format(Locale.US, "Taxi Fare: AED 12.00")
        } else {
            taxiFareTextView.text = String.format(Locale.US, "Taxi Fare: AED %.2f", taxiFare)
        }

        val busFare = distance * 0.05
        busFareTextView.text = String.format(Locale.US, "Bus Fare: AED %.2f", 2 + busFare)

        // Assuming 10 kilometers per liter and $2.50 per liter for car fuel cost
        val carFuelCost = (distance / 10) * 3.34
        carFuelCostTextView.text = String.format(Locale.US, "Car Fuel Cost: AED %.2f", carFuelCost)
    }


}