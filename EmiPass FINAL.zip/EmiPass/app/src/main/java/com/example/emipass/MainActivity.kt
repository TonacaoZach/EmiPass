package com.example.emipass

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.MenuItem
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import com.google.android.gms.common.api.Status
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.widget.AutocompleteSupportFragment
import com.google.android.libraries.places.widget.listener.PlaceSelectionListener
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity(), OnMapReadyCallback, NavigationView.OnNavigationItemSelectedListener {

    private lateinit var drawerLayout: DrawerLayout
    private var mGoogleMap: GoogleMap? = null
    private lateinit var autocompleteFragment: AutocompleteSupportFragment
    private val DEFAULT_LOCATION = LatLng(24.498639, 54.3745)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        drawerLayout = findViewById(R.id.MainDrawer)
        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)

        val navigationView = findViewById<NavigationView>(R.id.nav_view)
        navigationView.setNavigationItemSelectedListener(this)

        val toggle = ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open_nav, R.string.close_nav)
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        Places.initialize(applicationContext, getString(R.string.google_map_api_key))
        val autocompleteFragment = supportFragmentManager.findFragmentById(R.id.autocomplete_fragment)
                as AutocompleteSupportFragment
        autocompleteFragment.setPlaceFields(
            listOf(Place.Field.ID, Place.Field.ADDRESS, Place.Field.LAT_LNG)
        )
        autocompleteFragment.setOnPlaceSelectedListener(object : PlaceSelectionListener {
            override fun onError(status: Status) {
                Toast.makeText(this@MainActivity, "Some Error in Search", Toast.LENGTH_SHORT).show()
            }

            override fun onPlaceSelected(place: Place) {
                val latLng = place.latLng
                if (latLng != null) {
                    zoomOnMap(latLng)
                }
            }
        })

        val autocompleteView = autocompleteFragment.view
        val et = autocompleteView?.findViewById<EditText>(R.id.autocomplete_fragment)
        et?.setTextColor(Color.BLACK)

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.mapFragment) as SupportMapFragment
        mapFragment.getMapAsync(this)

        setupNavigationClickListeners()
    }

    private fun setupNavigationClickListeners() {
        findViewById<NavigationView>(R.id.nav_view).menu.findItem(R.id.home).setOnMenuItemClickListener {
            val maing = Intent(this@MainActivity, MainActivity::class.java)
            startActivity(maing)
            finish()
            drawerLayout.closeDrawer(GravityCompat.START)
            true
        }
        findViewById<NavigationView>(R.id.nav_view).menu.findItem(R.id.bus).setOnMenuItemClickListener {
            replaceFragment(PublicTransport())
            drawerLayout.closeDrawer(GravityCompat.START)
            true
        }
        findViewById<NavigationView>(R.id.nav_view).menu.findItem(R.id.payment).setOnMenuItemClickListener {
            replaceFragment(Payments())
            drawerLayout.closeDrawer(GravityCompat.START)
            true
        }
        findViewById<NavigationView>(R.id.nav_view).menu.findItem(R.id.card).setOnMenuItemClickListener {
            replaceFragment(Transactions())
            drawerLayout.closeDrawer(GravityCompat.START)
            true
        }
        findViewById<NavigationView>(R.id.nav_view).menu.findItem(R.id.journey).setOnMenuItemClickListener {
            replaceFragment(JourneyPlanner())
            drawerLayout.closeDrawer(GravityCompat.START)
            true
        }
        findViewById<NavigationView>(R.id.nav_view).menu.findItem(R.id.taxi).setOnMenuItemClickListener {
            replaceFragment(BookATaxi())
            drawerLayout.closeDrawer(GravityCompat.START)
            true
        }
        findViewById<NavigationView>(R.id.nav_view).menu.findItem(R.id.calculate).setOnMenuItemClickListener {
            replaceFragment(CalculateFare())
            drawerLayout.closeDrawer(GravityCompat.START)
            true
        }
        findViewById<NavigationView>(R.id.nav_view).menu.findItem(R.id.traffic).setOnMenuItemClickListener {
            replaceFragment(LiveTraffic())
            drawerLayout.closeDrawer(GravityCompat.START)
            true
        }
        findViewById<NavigationView>(R.id.nav_view).menu.findItem(R.id.logout).setOnMenuItemClickListener {
            Toast.makeText(this, "Logged Out", Toast.LENGTH_SHORT).show()
            val logout = Intent(this@MainActivity, ActivityLogin::class.java)
            startActivity(logout)
            finish()
            true
        }

        val helpMenuItem = findViewById<NavigationView>(R.id.nav_view).menu.findItem(R.id.help)

        helpMenuItem.setOnMenuItemClickListener {
            showInstructionsDialog()

            replaceFragment(HomeFragment())

            drawerLayout.closeDrawer(GravityCompat.START)
            true
        }
    }

    // Define the function to show the instructions dialog
    private fun showInstructionsDialog() {
        val dialog = Dialog(this)
        dialog.setContentView(R.layout.fragment_help)

        // Adjust dialog size
        val window = dialog.window
        if (window != null) {
            val layoutParams = WindowManager.LayoutParams()
            layoutParams.copyFrom(window.attributes)
            layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT
            layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT
            window.attributes = layoutParams
        }

        val closeButton = dialog.findViewById<Button>(R.id.close_button)
        closeButton.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun replaceFragment(fragment: Fragment) {
        val transaction: FragmentTransaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.fragment_container, fragment)
        transaction.addToBackStack(null)
        transaction.commit()
    }

    private fun zoomOnMap(latLng: LatLng) {
        val newLatLngZoom = CameraUpdateFactory.newLatLngZoom(latLng, 10f)
        mGoogleMap?.animateCamera(newLatLngZoom)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mGoogleMap = googleMap
        mGoogleMap?.moveCamera(CameraUpdateFactory.newLatLngZoom(DEFAULT_LOCATION, 13f))
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        // This is now handled individually in setupNavigationClickListeners
        return true
    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }
}
