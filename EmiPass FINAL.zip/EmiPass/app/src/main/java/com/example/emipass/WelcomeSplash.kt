package com.example.emipass

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.VideoView

class WelcomeSplash : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome_splash)

        val videoView: VideoView = findViewById(R.id.welcomesplash)
        val videoPath = "android.resource://${packageName}/${R.raw.welcome_splash}"

        val videoUri: Uri = Uri.parse(videoPath)
        videoView.setVideoURI(videoUri)
        videoView.start()

        videoView.setOnCompletionListener {
            val intent = Intent(this@WelcomeSplash, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}